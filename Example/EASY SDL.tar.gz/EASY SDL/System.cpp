#include"System.hpp"

System::System()
{
    //ctor
}

System::~System()
{
    //dtor
}
